# 🌸 Pinkie for Vscode 🌸

*"For all the cute girls who aren't super tech-savvy and the sweetest, gentlest boys out there~ (´｡• ᵕ •｡`) ♡"*

Made with lots of love 💖 by **JustDuyen**.

---

Welcome to **Pinkie for Vscode**! A super adorable, sweet pastel pink theme crafted just for Visual Studio Code and Antigravity! (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ Inspired by the cozy Light Pink Obsidian interface, this theme is designed to make your workspace neat, feminine, and incredibly relaxing. 🎀

## ✨ Super Cute Features ✨

- 🌸 **Sweet Pastel Palette**: A lovely white-pink background paired with deep pink accents that are super gentle on your eyes. It feels like coding on a fluffy cloud! ☁️
- 🌙 **Dark Pink but Make it Kawaii**: A super smooth dark mode with a minimalist dark background and glowing pink neon outlines for our cute night owls! (¬‿¬ )
- 🐈 **Flat & Minimalist UI**: We completely removed those distracting folder tree lines, bringing you an absolute clean, super flat, and friendly interface. No more messy lines!
- 🎨 **Easy-to-Read Code**: Code highlighting is beautifully re-tuned with soft pastel violet, ruby, and blue tones. Reading code has never been this pretty! ╰(*´︶`*)╯♡

## 📸 Sneak Peek

### Light Pink Mode 🌸
![Super cute white cat on light pink background](icon.png)

### Dark Pink Mode 🌙
![Super cute white cat on dark pink background](dark-icon.png)

## 🎀 How to Activate (It's super easy!)

1. Press `Ctrl + K` then `Ctrl + T`.
2. Type **Pink** and select either **Light Pink** or **Dark Pink**.
3. Yay! Enjoy your super cute new workspace! 🎉

*Enjoy coding with love & cuteness!* ✨ (´ ω `♡)
